package AutomationProject;

public class Constants {


}
